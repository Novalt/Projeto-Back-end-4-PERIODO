var quad = document.getElementById("home-menu")

var quad1 = document.getElementById("sobre-menu")

var quad2 = document.getElementById("contato-menu")







function ficarazul1() {
    quad.style.backgroundColor = "#0c173d"

}
function ficarverde1() {
    quad.style.backgroundColor = "#008037"

}




function ficarazul2() {
    quad1.style.backgroundColor = "#0c173d"
}
function ficarverde2() {
    quad1.style.backgroundColor = "#008037"

}




function ficarazul3() {
    quad2.style.backgroundColor = "#0c173d"
}
function ficarverde3() {
    quad2.style.backgroundColor = "#008037"

}


